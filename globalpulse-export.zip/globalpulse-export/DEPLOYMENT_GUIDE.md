# GlobalPulse — Full Deployment Guide

## Deploy Frontend on Netlify + Backend on Render + PostgreSQL on Render

This guide walks you through every single step to host GlobalPulse outside of Replit.

---

## Architecture Overview

```
┌──────────────────┐     API calls      ┌──────────────────┐     SQL      ┌──────────────┐
│   FRONTEND       │ ─────────────────► │   BACKEND        │ ──────────► │  PostgreSQL   │
│   (Netlify)      │                    │   (Render)       │             │  (Render)     │
│   React + Vite   │ ◄───────────────── │   Express API    │ ◄────────── │  Database     │
│   Static files   │     JSON responses │   Port 10000     │             │               │
└──────────────────┘                    └──────────────────┘             └──────────────┘
```

- **Frontend**: React + Vite → builds to static HTML/CSS/JS → hosted on Netlify (free tier)
- **Backend**: Express.js API → runs on Render Web Service (free tier)
- **Database**: PostgreSQL → Render managed database (free tier, 90 days)

---

## STEP 1: Create PostgreSQL Database on Render

1. Go to [https://render.com](https://render.com) and sign up / log in
2. Click **"New +"** → **"PostgreSQL"**
3. Fill in:
   - **Name**: `globalpulse-db`
   - **Database**: `globalpulse`
   - **User**: `globalpulse_user`
   - **Region**: Pick the closest to your users (e.g., Oregon US West)
   - **Plan**: Free (or paid for more storage/uptime)
4. Click **"Create Database"**
5. Wait for it to spin up (~1 min)
6. Copy the **"External Database URL"** — it looks like:
   ```
   postgresql://globalpulse_user:XXXXX@dpg-XXXXX.oregon-postgres.render.com/globalpulse
   ```
   **Save this URL. You'll need it in Step 2 and Step 3.**

---

## STEP 2: Deploy Backend on Render

### 2.1 Push code to GitHub

1. Create a new GitHub repository (e.g., `globalpulse`)
2. Unzip the `globalpulse-export.zip` file
3. Push the entire contents to GitHub:
   ```bash
   cd globalpulse-export
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/globalpulse.git
   git push -u origin main
   ```

### 2.2 Create Render Web Service

1. Go to Render Dashboard → **"New +"** → **"Web Service"**
2. Connect your GitHub repo (`globalpulse`)
3. Fill in these settings:

| Setting | Value |
|---------|-------|
| **Name** | `globalpulse-api` |
| **Region** | Same as your database |
| **Branch** | `main` |
| **Root Directory** | *(leave empty)* |
| **Runtime** | `Node` |
| **Build Command** | `npm install -g pnpm && pnpm install && pnpm --filter @workspace/db run push && cd artifacts/api-server && node ./build.mjs` |
| **Start Command** | `node artifacts/api-server/dist/index.mjs` |
| **Plan** | Free |

### 2.3 Set Environment Variables on Render

Go to the **"Environment"** tab of your Render Web Service and add:

| Variable | Value |
|----------|-------|
| `DATABASE_URL` | `postgresql://globalpulse_user:XXXXX@dpg-XXXXX.oregon-postgres.render.com/globalpulse` (the External URL from Step 1) |
| `PORT` | `10000` |
| `NODE_ENV` | `production` |
| `SESSION_SECRET` | Any random string, e.g. `my-super-secret-key-12345` |

4. Click **"Create Web Service"**
5. Wait for the first deploy to complete (~3-5 minutes)
6. Your API will be live at something like:
   ```
   https://globalpulse-api.onrender.com
   ```
   **Copy this URL — you'll need it in Step 3.**

### 2.4 Verify Backend is Running

Visit `https://globalpulse-api.onrender.com/api/healthz` in your browser.
You should see: `{"status":"ok"}`

Also check `https://globalpulse-api.onrender.com/api/market-data` — you should see market data JSON.

---

## STEP 3: Deploy Frontend on Netlify

### 3.1 Modify Frontend for External API

Before deploying, you need to tell the frontend where the API lives.

Edit `artifacts/market-screener/src/main.tsx` and add this line **before** `ReactDOM.createRoot(...)`:

```typescript
import { setBaseUrl } from "@workspace/api-client-react";

// Point to your Render backend URL (no trailing slash)
setBaseUrl("https://globalpulse-api.onrender.com");
```

Your `main.tsx` should look like:
```typescript
import React from "react";
import ReactDOM from "react-dom/client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { setBaseUrl } from "@workspace/api-client-react";
import App from "./App";
import "./index.css";

// IMPORTANT: Set your Render backend URL here
setBaseUrl("https://globalpulse-api.onrender.com");

const queryClient = new QueryClient({
  defaultOptions: { queries: { refetchOnWindowFocus: false } },
});

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <App />
    </QueryClientProvider>
  </React.StrictMode>
);
```

### 3.2 Build the Frontend Locally

```bash
cd globalpulse-export

# Install all dependencies
npm install -g pnpm
pnpm install

# Build the frontend (set required env vars for Vite)
cd artifacts/market-screener
PORT=3000 BASE_PATH="/" pnpm run build
```

This creates `artifacts/market-screener/dist/public/` with all your static files.

### 3.3 Deploy to Netlify

**Option A: Netlify CLI (Recommended)**

```bash
npm install -g netlify-cli
netlify login
netlify deploy --prod --dir=artifacts/market-screener/dist/public
```

**Option B: Netlify Dashboard (Drag & Drop)**

1. Go to [https://app.netlify.com](https://app.netlify.com)
2. Click **"Add new site"** → **"Deploy manually"**
3. Drag and drop the `artifacts/market-screener/dist/public` folder
4. Done! Your site is live.

**Option C: Netlify CI/CD from GitHub**

1. Go to Netlify → **"Add new site"** → **"Import an existing project"**
2. Connect your GitHub repo
3. Configure:

| Setting | Value |
|---------|-------|
| **Base directory** | *(leave empty)* |
| **Build command** | `npm install -g pnpm && pnpm install && cd artifacts/market-screener && PORT=3000 BASE_PATH="/" pnpm run build` |
| **Publish directory** | `artifacts/market-screener/dist/public` |

4. Add environment variables:

| Variable | Value |
|----------|-------|
| `PORT` | `3000` |
| `BASE_PATH` | `/` |

5. Click **"Deploy site"**

### 3.4 Configure Netlify Redirects (SPA Routing)

Create a `_redirects` file in `artifacts/market-screener/dist/public/` (or `artifacts/market-screener/public/`):

```
/*    /index.html   200
```

This ensures client-side routing works (e.g., `/markets`, `/stocks`).

Alternatively, create `netlify.toml` in the project root:

```toml
[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
```

---

## STEP 4: Enable CORS on Backend

The backend already has CORS enabled (`app.use(cors())`), which allows all origins.
If you want to restrict it to only your Netlify domain, edit `artifacts/api-server/src/app.ts`:

```typescript
app.use(cors({
  origin: "https://your-site-name.netlify.app",
  credentials: true,
}));
```

---

## STEP 5: Verify Everything Works

1. Open your Netlify URL (e.g., `https://globalpulse.netlify.app`)
2. You should see the GlobalPulse dashboard loading with live data
3. Check all pages:
   - Dashboard (USD Signal, IPOs, Key Conclusion)
   - Markets (live prices)
   - Stocks (NSE + US stocks)
   - Economics (indicators + calendar)
   - Geopolitical (events + risk heatmap)
   - News (Global Financial News + Forex News tabs)
   - Social Intel (Trump, Musk, Powell, Buffett, etc.)

---

## Environment Variables Reference

### Backend (Render)
| Variable | Required | Description | Example |
|----------|----------|-------------|---------|
| `DATABASE_URL` | Yes | PostgreSQL connection string | `postgresql://user:pass@host/db` |
| `PORT` | Yes | Port the server listens on | `10000` |
| `NODE_ENV` | Yes | Node environment | `production` |
| `SESSION_SECRET` | Yes | Session encryption key | `any-random-string-here` |

### Frontend (Netlify)
| Variable | Required | Description | Example |
|----------|----------|-------------|---------|
| `PORT` | Yes (build only) | Vite build port | `3000` |
| `BASE_PATH` | Yes (build only) | Base URL path | `/` |

---

## How Data Works (No External API Keys Needed!)

GlobalPulse fetches ALL data from free, public sources. No API keys required:

| Data Source | Method | Refresh Rate |
|-------------|--------|-------------|
| **Market Prices** (indices, forex, crypto, commodities, bonds) | Yahoo Finance API (public, no key) | Every 60 seconds |
| **Stock Prices** (NSE + US) | Yahoo Finance API (public, no key) | Every 30 seconds |
| **Financial News** | RSS feeds (CNBC, BBC, Investing.com, WSJ, etc.) | Every 60 seconds |
| **Social Intelligence** | Google News RSS + targeted search queries per leader | Every 60 seconds |
| **Economic Indicators** | Hardcoded seed data (GDP, inflation, rates, employment) | On server start |
| **Geopolitical Events** | Hardcoded seed data (conflicts, trade disputes, sanctions) | On server start |
| **IPO Data** | Google News RSS search for "IPO India" | Every 1 hour |
| **USD Direction Signal** | Computed from DXY, Gold, Oil, VIX prices | Every 1 hour |
| **Forex Calendar** | Google News RSS + scheduled event generator | Every 1 hour |

**All RSS feeds are public and require zero API keys or authentication.**

---

## Database Schema (Auto-Created)

The `pnpm --filter @workspace/db run push` command in the build step automatically creates all tables:

| Table | Description |
|-------|-------------|
| `market_assets` | Live prices for indices, forex, crypto, commodities, bonds |
| `economic_indicators` | GDP, inflation, interest rates, unemployment by country |
| `economic_events` | Scheduled economic calendar events |
| `geopolitical_events` | Active conflicts, trade wars, sanctions with risk scores |
| `news_items` | Financial news with impact analysis and trading conclusions |
| `social_posts` | Influencer/leader tracking (Trump, Musk, Powell, etc.) |
| `ipo_listings` | Indian IPO data with scoring and analysis |
| `usd_signals` | USD direction signal with factors and confidence |
| `watchlist` | User-saved watchlist items |
| `forex_calendar` | Forex economic calendar events with pair impact |

---

## Troubleshooting

### Backend won't start on Render
- Check the **"Logs"** tab in Render dashboard
- Make sure `DATABASE_URL` is set correctly (use External URL, not Internal)
- Make sure `PORT` is set to `10000`

### Frontend shows "Loading..." forever
- Open browser DevTools → Console tab
- Check for CORS errors or network failures
- Make sure `setBaseUrl(...)` points to the correct Render URL
- Make sure the Render backend is actually running (check `/api/healthz`)

### Database connection errors
- Verify the DATABASE_URL has the correct password and host
- On Render free tier, the database sleeps after 15 min of inactivity — first request may take 10-30s

### Render free tier spins down
- Free tier web services spin down after 15 min of inactivity
- First request after spin-down takes ~30 seconds to cold-start
- For always-on, upgrade to Render's paid plan ($7/month)

### No data showing up
- The backend auto-fetches data on startup from RSS feeds
- Wait 1-2 minutes after deploy for data to populate
- Check Render logs for any RSS fetch errors

---

## Project File Structure

```
globalpulse-export/
├── package.json                    # Root workspace config
├── pnpm-workspace.yaml             # pnpm workspace definition
├── tsconfig.json                   # Root TypeScript config
├── DEPLOYMENT_GUIDE.md             # This file
│
├── artifacts/
│   ├── api-server/                 # EXPRESS BACKEND
│   │   ├── package.json
│   │   ├── build.mjs               # Esbuild bundler config
│   │   ├── tsconfig.json
│   │   └── src/
│   │       ├── index.ts            # Server entry point
│   │       ├── app.ts              # Express app setup (CORS, routes)
│   │       ├── routes/             # All API endpoints
│   │       │   ├── index.ts        # Route aggregator
│   │       │   ├── market-data.ts  # /api/market-data
│   │       │   ├── stocks.ts       # /api/stocks
│   │       │   ├── news.ts         # /api/news
│   │       │   ├── social.ts       # /api/social
│   │       │   ├── economic.ts     # /api/economic-indicators
│   │       │   ├── geopolitical.ts # /api/geopolitical
│   │       │   ├── ipo.ts          # /api/ipo
│   │       │   ├── usd-signal.ts   # /api/usd-signal
│   │       │   ├── forex-calendar.ts # /api/forex-calendar
│   │       │   ├── dashboard.ts    # /api/dashboard
│   │       │   ├── watchlist.ts    # /api/watchlist
│   │       │   └── health.ts       # /api/healthz
│   │       └── lib/                # Data fetching & refresh logic
│   │           ├── marketRefresh.ts    # Yahoo Finance price fetcher
│   │           ├── newsRefresh.ts      # RSS news aggregator
│   │           ├── socialRefresh.ts    # Leader/influencer tracker
│   │           ├── ipoRefresh.ts       # IPO data fetcher
│   │           ├── usdSignalRefresh.ts # USD direction calculator
│   │           ├── forexCalendarRefresh.ts # Forex calendar
│   │           ├── seed.ts             # Database seeder
│   │           └── logger.ts           # Pino logger
│   │
│   └── market-screener/            # REACT FRONTEND
│       ├── package.json
│       ├── vite.config.ts          # Vite build config
│       ├── tsconfig.json
│       ├── index.html
│       ├── components.json         # Shadcn UI config
│       └── src/
│           ├── main.tsx            # Entry point (set API base URL here!)
│           ├── App.tsx             # Router + layout
│           ├── index.css           # Global styles
│           ├── pages/              # All page components
│           │   ├── Dashboard.tsx
│           │   ├── Markets.tsx
│           │   ├── Stocks.tsx
│           │   ├── Economics.tsx
│           │   ├── Geopolitical.tsx
│           │   ├── News.tsx
│           │   ├── Social.tsx
│           │   └── Watchlist.tsx
│           ├── components/         # Shared UI components
│           │   ├── Sidebar.tsx
│           │   ├── BreakingTicker.tsx
│           │   ├── AssetChartPanel.tsx
│           │   └── ui/             # Shadcn UI components
│           └── lib/
│               └── utils.ts
│
├── lib/
│   ├── db/                         # DATABASE LAYER
│   │   ├── package.json
│   │   ├── drizzle.config.ts       # Drizzle ORM config
│   │   └── src/
│   │       ├── index.ts            # DB connection
│   │       └── schema/
│   │           ├── index.ts
│   │           └── market.ts       # All table definitions
│   │
│   ├── api-spec/                   # OPENAPI SPECIFICATION
│   │   ├── package.json
│   │   ├── openapi.yaml            # API spec (source of truth)
│   │   └── orval.config.ts         # Code generator config
│   │
│   ├── api-client-react/           # GENERATED API CLIENT
│   │   ├── package.json
│   │   └── src/
│   │       ├── index.ts
│   │       ├── custom-fetch.ts     # Fetch wrapper with setBaseUrl()
│   │       └── generated/
│   │           ├── api.ts          # Generated React Query hooks
│   │           └── api.schemas.ts  # Generated TypeScript types
│   │
│   └── api-zod/                    # GENERATED ZOD SCHEMAS
│       ├── package.json
│       └── src/
│           └── generated/
│               └── api.zod.ts
│
└── scripts/                        # Utility scripts
    └── package.json
```

---

## Quick Deploy Checklist

- [ ] Create PostgreSQL database on Render
- [ ] Copy the External Database URL
- [ ] Push code to GitHub
- [ ] Create Render Web Service with correct build/start commands
- [ ] Set `DATABASE_URL`, `PORT=10000`, `NODE_ENV=production`, `SESSION_SECRET` on Render
- [ ] Wait for backend to deploy and verify `/api/healthz`
- [ ] Edit `main.tsx` to add `setBaseUrl("https://your-api.onrender.com")`
- [ ] Build frontend locally or via Netlify CI
- [ ] Deploy `dist/public` folder to Netlify
- [ ] Add `_redirects` file for SPA routing
- [ ] Test all pages on live site
- [ ] Done!

---

## Optional: Custom Domain

### Netlify Custom Domain
1. Go to Netlify site settings → Domain management
2. Add your custom domain (e.g., `globalpulse.yourdomain.com`)
3. Update DNS with your registrar (CNAME to `your-site.netlify.app`)

### Render Custom Domain
1. Go to Render Web Service settings → Custom Domains
2. Add your API domain (e.g., `api.globalpulse.yourdomain.com`)
3. Update DNS with your registrar
4. Update `setBaseUrl(...)` in `main.tsx` to match

---

## Alternative: Deploy Everything on Render (No Netlify)

You can also serve the frontend from Render itself:

1. Build frontend and copy `dist/public/` into the backend
2. Add this to `artifacts/api-server/src/app.ts` before `export default app`:
   ```typescript
   import path from "path";
   app.use(express.static(path.join(__dirname, "../market-screener/dist/public")));
   app.get("*", (req, res) => {
     if (!req.path.startsWith("/api")) {
       res.sendFile(path.join(__dirname, "../market-screener/dist/public/index.html"));
     }
   });
   ```
3. Update Render build command:
   ```
   npm install -g pnpm && pnpm install && pnpm --filter @workspace/db run push && cd artifacts/market-screener && PORT=3000 BASE_PATH="/" pnpm run build && cd ../api-server && node ./build.mjs
   ```
4. No need for `setBaseUrl()` since frontend and backend share the same origin

---

*Generated for GlobalPulse — Global Market Intelligence Terminal*
*All data sourced from free public RSS feeds and Yahoo Finance. No API keys required.*
