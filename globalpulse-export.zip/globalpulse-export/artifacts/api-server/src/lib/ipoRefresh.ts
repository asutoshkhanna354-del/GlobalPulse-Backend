import { db } from "@workspace/db";
import { ipoListingsTable } from "@workspace/db";
import { logger } from "./logger";

const HEADERS = {
  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
  "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
};

interface RawIpo {
  companyName: string;
  symbol?: string;
  issueSize?: string;
  priceRange?: string;
  openDate?: string;
  closeDate?: string;
  listingDate?: string;
  lotSize?: number;
  ipoType: string;
  status: string;
  gmp?: number;
  subscriptionQib?: number;
  subscriptionHni?: number;
  subscriptionRetail?: number;
  subscriptionTotal?: number;
  industry?: string;
  revenue?: string;
  profit?: string;
  companyDescription?: string;
  sourceUrl?: string;
}

function cleanText(html: string): string {
  return html
    .replace(/<!\[CDATA\[|\]\]>/g, "")
    .replace(/<[^>]+>/g, "")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&#\d+;/g, "")
    .replace(/&nbsp;/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function extractIpoName(title: string): string | null {
  const patterns = [
    /^([\w\s&.,'()-]+?)\s+IPO\b/i,
    /^([\w\s&.,'()-]+?)\s+(?:opens|closes|listing|allotment|GMP|subscription)/i,
    /IPO[:\s]+([\w\s&.,'()-]+?)(?:\s+(?:opens|closes|listing|GMP|price))/i,
  ];

  for (const pattern of patterns) {
    const match = title.match(pattern);
    if (match) {
      let name = match[1].trim();
      name = name.replace(/^(Upcoming|Top|India|Best|New|Latest|Why|How|These|This)\s+/i, "");
      name = name.replace(/\s*(IPO|Limited|Ltd|Inc)\s*$/i, "").trim();
      if (name.includes(",") && name.split(",").length > 2) continue;
      if (name.length >= 3 && name.length <= 50 && !/^\d+$/.test(name) && !/(market|stock|share|invest|bull|bear|surge|ipo\s|financial|upcoming|companies|mega|worth|over|nse|bse)/i.test(name)) {
        return name;
      }
    }
  }
  return null;
}

function extractIpoDetails(title: string, description?: string): Partial<RawIpo> {
  const text = `${title} ${description || ""}`;
  const details: Partial<RawIpo> = {};

  const gmpMatch = text.match(/GMP[:\s]*[₹Rs.]*\s*([+-]?\d+)/i);
  if (gmpMatch) details.gmp = parseFloat(gmpMatch[1]);

  const priceMatch = text.match(/(?:price\s*(?:band|range)?[:\s]*)?[₹Rs.]*\s*(\d[\d,]*)\s*(?:to|-)\s*[₹Rs.]*\s*(\d[\d,]*)/i);
  if (priceMatch) details.priceRange = `${priceMatch[1].replace(/,/g, "")}-${priceMatch[2].replace(/,/g, "")}`;

  const sizeMatch = text.match(/(?:issue\s*size|worth|₹|Rs\.?)\s*(\d[\d,.]*)\s*(?:Cr|crore|lakh\s*crore)/i);
  if (sizeMatch) details.issueSize = `₹${sizeMatch[1]} ${text.match(/lakh\s*crore/i) ? "Lakh Crore" : "Cr"}`;

  const lotMatch = text.match(/lot\s*size[:\s]*(\d+)/i);
  if (lotMatch) details.lotSize = parseInt(lotMatch[1]);

  const subMatch = text.match(/subscription[:\s]*(\d+\.?\d*)\s*x/i) || text.match(/subscribed\s*(\d+\.?\d*)\s*(?:times|x)/i);
  if (subMatch) details.subscriptionTotal = parseFloat(subMatch[1]);

  if (text.toLowerCase().includes("sme")) details.ipoType = "sme";

  return details;
}

async function fetchFromGoogleNews(): Promise<RawIpo[]> {
  const ipos: RawIpo[] = [];
  const queries = [
    "IPO+India+upcoming+2026+GMP",
    "IPO+India+open+listing+2026",
    "NSE+BSE+IPO+new+listing+India",
  ];

  for (const q of queries) {
    try {
      const url = `https://news.google.com/rss/search?q=${q}&hl=en-IN&gl=IN&ceid=IN:en`;
      const res = await fetch(url, { headers: HEADERS, signal: AbortSignal.timeout(10000) });
      if (!res.ok) continue;
      const xml = await res.text();

      const itemRegex = /<item>([\s\S]*?)<\/item>/gi;
      let match;
      while ((match = itemRegex.exec(xml)) !== null) {
        const titleMatch = match[1].match(/<title[^>]*>([\s\S]*?)<\/title>/i);
        const title = titleMatch ? cleanText(titleMatch[1]) : "";
        if (!title) continue;

        const ipoName = extractIpoName(title);
        if (!ipoName) continue;

        const descMatch = match[1].match(/<description[^>]*>([\s\S]*?)<\/description>/i);
        const desc = descMatch ? cleanText(descMatch[1]).slice(0, 300) : undefined;

        const linkMatch = match[1].match(/<link[^>]*>([\s\S]*?)<\/link>/i);
        const sourceUrl = linkMatch ? cleanText(linkMatch[1]) : undefined;

        const pubDateMatch = match[1].match(/<pubDate[^>]*>([\s\S]*?)<\/pubDate>/i);
        const pubDate = pubDateMatch ? cleanText(pubDateMatch[1]) : undefined;

        const details = extractIpoDetails(title, desc);

        const statusLower = title.toLowerCase();
        let status = "upcoming";
        if (statusLower.includes("listed") || statusLower.includes("listing gain") || statusLower.includes("listing day")) {
          status = "listed";
        } else if (statusLower.includes("opens") || statusLower.includes("open for") || statusLower.includes("subscribe")) {
          status = "open";
        } else if (statusLower.includes("allotment") || statusLower.includes("closed")) {
          status = "closed";
        }

        ipos.push({
          companyName: ipoName,
          ipoType: details.ipoType || "mainboard",
          status,
          gmp: details.gmp,
          priceRange: details.priceRange,
          issueSize: details.issueSize,
          lotSize: details.lotSize,
          subscriptionTotal: details.subscriptionTotal,
          companyDescription: desc,
          sourceUrl,
          ...(pubDate ? { openDate: new Date(pubDate).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }) } : {}),
        });
      }
    } catch (err) {
      logger.warn({ err: String(err), query: q }, "Failed to fetch Google News RSS");
    }
  }

  logger.info({ count: ipos.length }, "Fetched IPOs from Google News RSS");
  return ipos;
}

async function fetchFromNdtvProfit(): Promise<RawIpo[]> {
  const ipos: RawIpo[] = [];
  try {
    const res = await fetch("https://www.ndtv.com/business/rss", {
      headers: HEADERS,
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) return [];
    const xml = await res.text();

    const itemRegex = /<item>([\s\S]*?)<\/item>/gi;
    let match;
    while ((match = itemRegex.exec(xml)) !== null) {
      const titleMatch = match[1].match(/<title[^>]*>([\s\S]*?)<\/title>/i);
      const title = titleMatch ? cleanText(titleMatch[1]) : "";
      if (!title.toLowerCase().includes("ipo")) continue;

      const ipoName = extractIpoName(title);
      if (!ipoName) continue;

      const linkMatch = match[1].match(/<link[^>]*>([\s\S]*?)<\/link>/i);
      const details = extractIpoDetails(title);

      ipos.push({
        companyName: ipoName,
        ipoType: details.ipoType || "mainboard",
        status: title.toLowerCase().includes("listing") ? "listed" : "upcoming",
        gmp: details.gmp,
        priceRange: details.priceRange,
        issueSize: details.issueSize,
        sourceUrl: linkMatch ? cleanText(linkMatch[1]) : undefined,
      });
    }
  } catch (err) {
    logger.warn({ err: String(err) }, "Failed to fetch NDTV IPO RSS");
  }
  logger.info({ count: ipos.length }, "Fetched IPOs from NDTV");
  return ipos;
}

function generateIpoAnalysis(ipo: RawIpo): {
  prosText: string;
  consText: string;
  recommendationListing: string;
  recommendationLongTerm: string;
  totalScore: number;
} {
  let financialScore = 5;
  let valuationScore = 5;
  let demandScore = 5;
  let promoterScore = 6;
  let fundsScore = 5;

  if (ipo.subscriptionTotal) {
    if (ipo.subscriptionTotal > 50) demandScore = 9;
    else if (ipo.subscriptionTotal > 20) demandScore = 8;
    else if (ipo.subscriptionTotal > 5) demandScore = 6;
    else if (ipo.subscriptionTotal > 1) demandScore = 4;
    else demandScore = 2;
  }

  if (ipo.gmp !== undefined) {
    if (ipo.gmp > 100) { demandScore = Math.min(10, demandScore + 2); valuationScore += 1; }
    else if (ipo.gmp > 50) { demandScore = Math.min(10, demandScore + 1); }
    else if (ipo.gmp > 0) { demandScore = Math.min(10, demandScore); }
    else if (ipo.gmp < 0) { demandScore = Math.max(1, demandScore - 2); valuationScore -= 1; }
  }

  if (ipo.subscriptionQib && ipo.subscriptionQib > 10) financialScore += 2;
  if (ipo.profit && ipo.profit.includes("-")) financialScore -= 2;

  if (ipo.ipoType === "sme") { financialScore -= 1; promoterScore -= 1; }

  financialScore = Math.max(1, Math.min(10, financialScore));
  valuationScore = Math.max(1, Math.min(10, valuationScore));
  demandScore = Math.max(1, Math.min(10, demandScore));
  promoterScore = Math.max(1, Math.min(10, promoterScore));
  fundsScore = Math.max(1, Math.min(10, fundsScore));

  const totalScore = financialScore + valuationScore + demandScore + promoterScore + fundsScore;

  const pros: string[] = [];
  const cons: string[] = [];

  if (ipo.gmp && ipo.gmp > 0) pros.push(`Positive GMP of ₹${ipo.gmp} indicates strong listing potential`);
  if (ipo.subscriptionTotal && ipo.subscriptionTotal > 5) pros.push(`Strong subscription of ${ipo.subscriptionTotal.toFixed(1)}x shows high demand`);
  if (ipo.subscriptionQib && ipo.subscriptionQib > 5) pros.push(`QIB subscription of ${ipo.subscriptionQib.toFixed(1)}x shows institutional confidence`);
  if (pros.length === 0) pros.push("Listed on major exchange (NSE/BSE)");
  if (pros.length < 2) pros.push("Sector growth potential in Indian market");
  if (pros.length < 3) pros.push("Primary market exposure opportunity");

  if (ipo.gmp !== undefined && ipo.gmp <= 0) cons.push("Negative/zero GMP suggests weak listing sentiment");
  if (ipo.subscriptionTotal && ipo.subscriptionTotal < 1) cons.push("Low subscription indicates weak demand");
  if (ipo.ipoType === "sme") cons.push("SME IPOs carry higher risk and lower liquidity");
  if (cons.length === 0) cons.push("Limited post-listing track record");
  if (cons.length < 2) cons.push("Market volatility risk around listing");
  if (cons.length < 3) cons.push("General market conditions may impact performance");

  let recommendationListing: string;
  let recommendationLongTerm: string;

  if (totalScore >= 40) {
    recommendationListing = "APPLY";
    recommendationLongTerm = "INVEST";
  } else if (totalScore >= 30) {
    recommendationListing = "APPLY";
    recommendationLongTerm = "WAIT";
  } else if (totalScore >= 20) {
    recommendationListing = "RISKY";
    recommendationLongTerm = "AVOID";
  } else {
    recommendationListing = "AVOID";
    recommendationLongTerm = "AVOID";
  }

  return {
    prosText: pros.slice(0, 3).join(" | "),
    consText: cons.slice(0, 3).join(" | "),
    recommendationListing,
    recommendationLongTerm,
    totalScore,
  };
}

function deduplicateIpos(ipos: RawIpo[]): RawIpo[] {
  const seen = new Map<string, RawIpo>();
  for (const ipo of ipos) {
    const key = ipo.companyName.toLowerCase().replace(/\s+/g, " ").replace(/limited|ltd|inc|pvt|private/gi, "").trim();
    if (key.length < 3) continue;
    const existing = seen.get(key);
    if (!existing) {
      seen.set(key, ipo);
    } else {
      seen.set(key, {
        ...existing,
        ...Object.fromEntries(Object.entries(ipo).filter(([, v]) => v !== undefined && v !== null)),
      });
    }
  }
  return Array.from(seen.values());
}

export async function refreshIpoData(): Promise<{ count: number }> {
  logger.info("Starting IPO data refresh");

  const [googleIpos, ndtvIpos] = await Promise.all([
    fetchFromGoogleNews().catch(() => [] as RawIpo[]),
    fetchFromNdtvProfit().catch(() => [] as RawIpo[]),
  ]);

  logger.info({
    googleNews: googleIpos.length,
    ndtv: ndtvIpos.length,
  }, "IPO sources fetched");

  const allIpos = deduplicateIpos([...googleIpos, ...ndtvIpos]);

  if (allIpos.length === 0) {
    logger.warn("No IPO data fetched from any source, keeping existing data");
    return { count: 0 };
  }

  const inserts = allIpos.map(ipo => {
    const analysis = generateIpoAnalysis(ipo);
    return {
      companyName: ipo.companyName,
      symbol: ipo.symbol ?? null,
      exchange: "NSE",
      issueSize: ipo.issueSize ?? null,
      priceRange: ipo.priceRange ?? null,
      openDate: ipo.openDate ?? null,
      closeDate: ipo.closeDate ?? null,
      listingDate: ipo.listingDate ?? null,
      lotSize: ipo.lotSize ?? null,
      ipoType: ipo.ipoType,
      status: ipo.status,
      gmp: ipo.gmp ?? null,
      subscriptionQib: ipo.subscriptionQib ?? null,
      subscriptionHni: ipo.subscriptionHni ?? null,
      subscriptionRetail: ipo.subscriptionRetail ?? null,
      subscriptionTotal: ipo.subscriptionTotal ?? null,
      industry: ipo.industry ?? null,
      revenue: ipo.revenue ?? null,
      profit: ipo.profit ?? null,
      companyDescription: ipo.companyDescription ?? null,
      prosText: analysis.prosText,
      consText: analysis.consText,
      recommendationListing: analysis.recommendationListing,
      recommendationLongTerm: analysis.recommendationLongTerm,
      totalScore: analysis.totalScore,
      listingPrice: null as number | null,
      listingGainPercent: null as number | null,
      currentPrice: null as number | null,
      sourceUrl: ipo.sourceUrl ?? null,
      lastUpdated: new Date(),
    };
  });

  if (inserts.length > 0) {
    await db.transaction(async (tx) => {
      await tx.delete(ipoListingsTable);
      await tx.insert(ipoListingsTable).values(inserts);
    });
  }

  logger.info({ count: inserts.length }, "IPO data refresh complete");
  return { count: inserts.length };
}
