import { db } from "@workspace/db";
import {
  usdSignalsTable,
  marketAssetsTable,
  newsItemsTable,
  geopoliticalEventsTable,
  socialPostsTable,
} from "@workspace/db";
import { desc, eq } from "drizzle-orm";
import { logger } from "./logger";

interface MarketContext {
  dxy: number | null;
  gold: number | null;
  oil: number | null;
  vix: number | null;
  sp500Change: number;
  btcChange: number;
  ustyield: number | null;
  dxyChange: number;
  goldChange: number;
  oilChange: number;
  bearishNewsCount: number;
  bullishNewsCount: number;
  geopoliticalRiskLevel: string;
  fedHawkish: boolean;
  fedDovish: boolean;
  tariffRisk: boolean;
}

async function gatherMarketContext(): Promise<MarketContext> {
  const [assets, news, geoEvents, socialPosts] = await Promise.all([
    db.select().from(marketAssetsTable),
    db.select().from(newsItemsTable),
    db.select().from(geopoliticalEventsTable),
    db.select().from(socialPostsTable),
  ]);

  const findAsset = (symbol: string) => assets.find(a => a.symbol === symbol);
  const findByName = (name: string) => assets.find(a => a.name.toLowerCase().includes(name.toLowerCase()));

  const dxy = findAsset("DXY") ?? findByName("Dollar Index");
  const gold = findAsset("XAUUSD") ?? findAsset("XAU/USD") ?? findByName("Gold");
  const oil = findAsset("USOIL") ?? findAsset("WTI") ?? findByName("WTI") ?? findByName("Crude");
  const vix = findAsset("VIX") ?? findByName("VIX");
  const sp500 = findAsset("SPX") ?? findAsset("S&P 500") ?? findByName("S&P");
  const btc = findAsset("BTC") ?? findByName("Bitcoin");
  const ustyield = findAsset("US10Y") ?? findByName("10-Year");

  const bearishNewsCount = news.filter(n =>
    n.sentiment === "bearish" || n.impact === "high"
  ).length;
  const bullishNewsCount = news.filter(n => n.sentiment === "bullish").length;

  const activeConflicts = geoEvents.filter(e =>
    e.status === "active" || e.status === "escalating"
  );
  const criticalCount = activeConflicts.filter(e => e.severity === "critical").length;
  const geopoliticalRiskLevel = criticalCount > 2 ? "extreme" :
    criticalCount > 0 ? "high" :
    activeConflicts.length > 3 ? "elevated" : "moderate";

  const fedPosts = socialPosts.filter(p =>
    p.category === "powell" || p.influencer?.toLowerCase().includes("powell") ||
    p.influencer?.toLowerCase().includes("fed")
  );
  const fedHawkish = fedPosts.some(p =>
    p.content.toLowerCase().includes("rate hike") ||
    p.content.toLowerCase().includes("hawkish") ||
    p.content.toLowerCase().includes("tighten") ||
    p.content.toLowerCase().includes("inflation concern")
  );
  const fedDovish = fedPosts.some(p =>
    p.content.toLowerCase().includes("rate cut") ||
    p.content.toLowerCase().includes("dovish") ||
    p.content.toLowerCase().includes("easing") ||
    p.content.toLowerCase().includes("pivot")
  );

  const tariffRisk = socialPosts.some(p =>
    p.content.toLowerCase().includes("tariff") ||
    p.content.toLowerCase().includes("trade war")
  ) || news.some(n =>
    n.headline.toLowerCase().includes("tariff") ||
    n.headline.toLowerCase().includes("trade war")
  );

  return {
    dxy: dxy?.price ?? null,
    gold: gold?.price ?? null,
    oil: oil?.price ?? null,
    vix: vix?.price ?? null,
    sp500Change: sp500?.changePercent ?? 0,
    btcChange: btc?.changePercent ?? 0,
    ustyield: ustyield?.price ?? null,
    dxyChange: dxy?.changePercent ?? 0,
    goldChange: gold?.changePercent ?? 0,
    oilChange: oil?.changePercent ?? 0,
    bearishNewsCount,
    bullishNewsCount,
    geopoliticalRiskLevel,
    fedHawkish,
    fedDovish,
    tariffRisk,
  };
}

function analyzeUsdDirection(ctx: MarketContext): {
  direction: string;
  confidence: number;
  summary: string;
  factors: string[];
  fedSignal: string;
  geopoliticalRisk: string;
} {
  let score = 0;
  const factors: string[] = [];

  if (ctx.dxyChange > 0.3) {
    score += 2;
    factors.push(`DXY rising +${ctx.dxyChange.toFixed(2)}% — USD momentum bullish`);
  } else if (ctx.dxyChange < -0.3) {
    score -= 2;
    factors.push(`DXY falling ${ctx.dxyChange.toFixed(2)}% — USD momentum bearish`);
  } else {
    factors.push(`DXY flat at ${ctx.dxy?.toFixed(2) ?? "N/A"} — neutral momentum`);
  }

  if (ctx.goldChange > 1) {
    score -= 1;
    factors.push(`Gold surging +${ctx.goldChange.toFixed(2)}% — safe haven demand weakens USD`);
  } else if (ctx.goldChange < -1) {
    score += 1;
    factors.push(`Gold declining ${ctx.goldChange.toFixed(2)}% — risk-on favors USD`);
  }

  if (ctx.vix && ctx.vix > 25) {
    score += 1;
    factors.push(`VIX elevated at ${ctx.vix.toFixed(1)} — flight to safety supports USD`);
  } else if (ctx.vix && ctx.vix < 15) {
    score -= 1;
    factors.push(`VIX low at ${ctx.vix.toFixed(1)} — risk appetite reduces USD demand`);
  }

  if (ctx.oilChange > 3) {
    score -= 1;
    factors.push(`Oil spiking +${ctx.oilChange.toFixed(1)}% — inflationary pressure mixed for USD`);
  }

  if (ctx.fedHawkish) {
    score += 2;
    factors.push("Fed signals hawkish — higher rates support USD");
  }
  if (ctx.fedDovish) {
    score -= 2;
    factors.push("Fed signals dovish — rate cut expectations weaken USD");
  }

  if (ctx.geopoliticalRiskLevel === "extreme" || ctx.geopoliticalRiskLevel === "high") {
    score += 1;
    factors.push(`Geopolitical risk ${ctx.geopoliticalRiskLevel} — safe haven flows into USD`);
  }

  if (ctx.tariffRisk) {
    score -= 1;
    factors.push("Trade/tariff tensions — creates USD uncertainty and volatility");
  }

  if (ctx.sp500Change < -1) {
    score += 1;
    factors.push(`S&P 500 falling ${ctx.sp500Change.toFixed(2)}% — equity weakness supports USD as safe haven`);
  } else if (ctx.sp500Change > 1) {
    score -= 0.5;
    factors.push(`S&P 500 rising +${ctx.sp500Change.toFixed(2)}% — risk-on reduces USD safe haven appeal`);
  }

  if (ctx.bearishNewsCount > ctx.bullishNewsCount * 2) {
    score += 1;
    factors.push(`News sentiment heavily bearish (${ctx.bearishNewsCount} bearish vs ${ctx.bullishNewsCount} bullish)`);
  } else if (ctx.bullishNewsCount > ctx.bearishNewsCount * 2) {
    score -= 0.5;
    factors.push(`News sentiment strongly bullish — risk assets preferred over USD`);
  }

  const direction = score > 1.5 ? "BULLISH" : score < -1.5 ? "BEARISH" : "NEUTRAL";
  const confidence = Math.min(95, Math.max(30, 50 + Math.abs(score) * 8));

  let summary = "";
  if (direction === "BULLISH") {
    summary = `USD likely to STRENGTHEN. ${factors.length} factors analyzed: DXY at ${ctx.dxy?.toFixed(2) ?? "N/A"}, ` +
      `gold at $${ctx.gold?.toFixed(0) ?? "N/A"}, VIX at ${ctx.vix?.toFixed(1) ?? "N/A"}. ` +
      `Key drivers: ${ctx.fedHawkish ? "hawkish Fed, " : ""}${ctx.geopoliticalRiskLevel === "high" || ctx.geopoliticalRiskLevel === "extreme" ? "geopolitical safe-haven, " : ""}${ctx.dxyChange > 0 ? "DXY momentum. " : ""}` +
      `Recommendation: Consider LONG USD positions, SHORT gold.`;
  } else if (direction === "BEARISH") {
    summary = `USD likely to WEAKEN. ${factors.length} factors analyzed: DXY at ${ctx.dxy?.toFixed(2) ?? "N/A"}, ` +
      `gold at $${ctx.gold?.toFixed(0) ?? "N/A"}, VIX at ${ctx.vix?.toFixed(1) ?? "N/A"}. ` +
      `Key drivers: ${ctx.fedDovish ? "dovish Fed, " : ""}${ctx.tariffRisk ? "trade tensions, " : ""}${ctx.goldChange > 0 ? "gold strength. " : ""}` +
      `Recommendation: Consider SHORT USD, LONG gold/EUR.`;
  } else {
    summary = `USD NEUTRAL — no clear direction. DXY at ${ctx.dxy?.toFixed(2) ?? "N/A"}, ` +
      `gold at $${ctx.gold?.toFixed(0) ?? "N/A"}, VIX at ${ctx.vix?.toFixed(1) ?? "N/A"}. ` +
      `Mixed signals from ${factors.length} analyzed factors. Recommendation: HOLD positions, wait for clearer signal.`;
  }

  const fedSignal = ctx.fedHawkish ? "hawkish" : ctx.fedDovish ? "dovish" : "neutral";

  return { direction, confidence: Math.round(confidence), summary, factors, fedSignal, geopoliticalRisk: ctx.geopoliticalRiskLevel };
}

export async function refreshUsdSignal(): Promise<{ direction: string; confidence: number }> {
  logger.info("Starting USD signal refresh");

  const ctx = await gatherMarketContext();
  const analysis = analyzeUsdDirection(ctx);

  const nextUpdate = new Date(Date.now() + 4 * 60 * 60 * 1000);

  await db.insert(usdSignalsTable).values({
    direction: analysis.direction,
    confidence: analysis.confidence,
    summary: analysis.summary,
    factors: analysis.factors,
    dxyValue: ctx.dxy,
    goldPrice: ctx.gold,
    oilPrice: ctx.oil,
    vixValue: ctx.vix,
    fedSignal: analysis.fedSignal,
    geopoliticalRisk: analysis.geopoliticalRisk,
    nextUpdate,
    createdAt: new Date(),
  });

  logger.info({ direction: analysis.direction, confidence: analysis.confidence }, "USD signal refresh complete");
  return { direction: analysis.direction, confidence: analysis.confidence };
}
