import { useGetBreakingNews } from "@workspace/api-client-react";
import { Zap } from "lucide-react";

export function BreakingTicker() {
  const { data: news } = useGetBreakingNews();

  if (!news?.length) return null;

  const tickerText = news.map(n => `  //  ${n.headline}`).join("  ");

  return (
    <div
      data-testid="breaking-ticker"
      className="bg-red-950/80 border-b border-red-800/60 flex items-center overflow-hidden h-8 shrink-0"
    >
      <div className="flex items-center gap-2 px-3 pl-12 lg:pl-3 shrink-0 border-r border-red-800/60">
        <Zap className="w-3 h-3 text-red-400" />
        <span className="text-[10px] font-bold text-red-400 uppercase tracking-widest whitespace-nowrap">Breaking</span>
      </div>
      <div className="flex-1 overflow-hidden relative">
        <div className="ticker-animate whitespace-nowrap text-[11px] text-red-200 py-2">
          {tickerText}
        </div>
      </div>
    </div>
  );
}
