import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import {
  LayoutDashboard,
  TrendingUp,
  BarChart3,
  Globe,
  Newspaper,
  Star,
  Activity,
  Zap,
  CandlestickChart,
  Radio,
  Menu,
  X,
} from "lucide-react";

const navItems = [
  { path: "/", label: "Dashboard", icon: LayoutDashboard },
  { path: "/markets", label: "Markets", icon: TrendingUp },
  { path: "/stocks", label: "Stocks", icon: CandlestickChart },
  { path: "/economics", label: "Economics", icon: BarChart3 },
  { path: "/geopolitical", label: "Geopolitical", icon: Globe },
  { path: "/news", label: "News", icon: Newspaper },
  { path: "/social", label: "Social Intel", icon: Radio, badge: "NEW" },
  { path: "/watchlist", label: "Watchlist", icon: Star },
];

export function Sidebar() {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    setMobileOpen(false);
  }, [location]);

  useEffect(() => {
    if (mobileOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => { document.body.style.overflow = ""; };
  }, [mobileOpen]);

  return (
    <>
      <button
        onClick={() => setMobileOpen(true)}
        className="lg:hidden fixed top-0 left-0 z-50 p-2.5 m-0 bg-sidebar border-r border-b border-sidebar-border rounded-br-lg"
        aria-label="Open menu"
      >
        <Menu className="w-5 h-5 text-foreground" />
      </button>

      {mobileOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black/60 z-40"
          onClick={() => setMobileOpen(false)}
        />
      )}

      <aside className={`
        fixed lg:relative z-50
        w-56 min-h-screen bg-sidebar border-r border-sidebar-border flex flex-col shrink-0
        transition-transform duration-200 ease-in-out
        ${mobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}
      `}>
        <div className="px-4 py-4 border-b border-sidebar-border flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded bg-primary flex items-center justify-center">
              <Activity className="w-4 h-4 text-primary-foreground" />
            </div>
            <div>
              <div className="text-sm font-semibold text-foreground tracking-wide">GlobalPulse</div>
              <div className="text-[10px] text-muted-foreground uppercase tracking-widest">Intelligence</div>
            </div>
          </div>
          <button
            onClick={() => setMobileOpen(false)}
            className="lg:hidden p-1 text-muted-foreground hover:text-foreground"
            aria-label="Close menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="flex-1 px-2 py-3 space-y-0.5 overflow-y-auto">
          {navItems.map(({ path, label, icon: Icon, badge }: { path: string; label: string; icon: any; badge?: string }) => {
            const isActive = path === "/" ? location === "/" : location.startsWith(path);
            return (
              <Link key={path} href={path}>
                <div
                  data-testid={`nav-${label.toLowerCase().replace(/\s+/g, "-")}`}
                  className={`flex items-center gap-3 px-3 py-2.5 lg:py-2 rounded text-sm transition-colors cursor-pointer ${
                    isActive
                      ? "bg-sidebar-accent text-foreground"
                      : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-foreground"
                  }`}
                >
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? "text-primary" : ""}`} />
                  <span>{label}</span>
                  {badge && !isActive && (
                    <span className="ml-auto text-[9px] bg-primary/20 text-primary border border-primary/30 px-1 py-0.5 rounded font-bold tracking-wider">
                      {badge}
                    </span>
                  )}
                  {isActive && <div className="ml-auto w-1 h-4 rounded-full bg-primary" />}
                </div>
              </Link>
            );
          })}
        </nav>

        <div className="px-4 py-3 border-t border-sidebar-border">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-500 live-pulse" />
            <span className="text-[11px] text-muted-foreground">Live Data</span>
            <Zap className="w-3 h-3 text-yellow-500 ml-auto" />
          </div>
          <div className="text-[10px] text-muted-foreground mt-1">
            Updated {new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
          </div>
        </div>
      </aside>
    </>
  );
}
