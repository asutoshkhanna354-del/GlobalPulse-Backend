import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { Sidebar } from "@/components/Sidebar";
import { BreakingTicker } from "@/components/BreakingTicker";
import { Dashboard } from "@/pages/Dashboard";
import { Markets } from "@/pages/Markets";
import { Economics } from "@/pages/Economics";
import { Geopolitical } from "@/pages/Geopolitical";
import { News } from "@/pages/News";
import { Watchlist } from "@/pages/Watchlist";
import { Stocks } from "@/pages/Stocks";
import { Social } from "@/pages/Social";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 30000,
      refetchInterval: 30000,
    },
  },
});

function AppLayout() {
  return (
    <div className="flex h-[100dvh] bg-background overflow-hidden">
      <Sidebar />
      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        <BreakingTicker />
        <main className="flex flex-1 overflow-hidden">
          <Switch>
            <Route path="/" component={Dashboard} />
            <Route path="/markets" component={Markets} />
            <Route path="/stocks" component={Stocks} />
            <Route path="/economics" component={Economics} />
            <Route path="/geopolitical" component={Geopolitical} />
            <Route path="/news" component={News} />
            <Route path="/social" component={Social} />
            <Route path="/watchlist" component={Watchlist} />
            <Route component={NotFound} />
          </Switch>
        </main>
      </div>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
        <AppLayout />
        <Toaster />
      </WouterRouter>
    </QueryClientProvider>
  );
}

export default App;
