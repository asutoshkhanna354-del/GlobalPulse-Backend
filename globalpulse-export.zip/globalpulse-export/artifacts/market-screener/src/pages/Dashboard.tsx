import { useState } from "react";
import {
  useGetDashboardOverview,
  useGetMarketSummary,
  useGetTopMovers,
  useGetBreakingNews,
} from "@workspace/api-client-react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import {
  TrendingUp,
  TrendingDown,
  Shield,
  Globe,
  Newspaper,
  ArrowUpRight,
  ArrowDownRight,
  DollarSign,
  Clock,
  Rocket,
  ChevronRight,
  RefreshCw,
  Zap,
  BarChart2,
} from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";

interface UsdSignal {
  direction: string;
  confidence: number;
  summary: string;
  factors: string[];
  dxyValue: number | null;
  goldPrice: number | null;
  oilPrice: number | null;
  vixValue: number | null;
  fedSignal: string;
  geopoliticalRisk: string;
  nextUpdate: string | null;
  createdAt: string;
}

interface IpoListing {
  id: number;
  companyName: string;
  symbol: string | null;
  exchange: string;
  issueSize: string | null;
  priceRange: string | null;
  openDate: string | null;
  closeDate: string | null;
  listingDate: string | null;
  lotSize: number | null;
  ipoType: string;
  status: string;
  gmp: number | null;
  subscriptionTotal: number | null;
  industry: string | null;
  recommendationListing: string | null;
  totalScore: number | null;
}

function UsdSignalBox() {
  const { data: signal, isLoading } = useQuery<UsdSignal>({
    queryKey: ["usd-signal"],
    queryFn: async () => {
      const res = await fetch("/api/usd-signal");
      if (!res.ok) throw new Error("Failed to fetch USD signal");
      return res.json();
    },
    refetchInterval: 60 * 1000,
  });

  if (isLoading || !signal) {
    return (
      <div className="bg-card border border-border rounded-lg p-4 animate-pulse">
        <div className="h-24" />
      </div>
    );
  }

  const dirColor = signal.direction === "BULLISH" ? "text-green-400" : signal.direction === "BEARISH" ? "text-red-400" : "text-yellow-400";
  const dirBg = signal.direction === "BULLISH" ? "bg-green-950/40 border-green-800/60" : signal.direction === "BEARISH" ? "bg-red-950/40 border-red-800/60" : "bg-yellow-950/40 border-yellow-800/60";
  const dirIcon = signal.direction === "BULLISH" ? ArrowUpRight : signal.direction === "BEARISH" ? ArrowDownRight : DollarSign;
  const DirIcon = dirIcon;

  const nextUpdateTime = signal.nextUpdate ? new Date(signal.nextUpdate).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "—";

  return (
    <div className={`border rounded-lg overflow-hidden ${dirBg}`}>
      <div className="px-4 py-2 border-b border-inherit flex items-center justify-between">
        <div className="flex items-center gap-2">
          <DollarSign className={`w-4 h-4 ${dirColor}`} />
          <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">USD Direction Signal</span>
        </div>
        <div className="flex items-center gap-2 text-[9px] text-muted-foreground">
          <Clock className="w-3 h-3" />
          Updates every 1hr · Next: {nextUpdateTime}
        </div>
      </div>

      <div className="p-4">
        <div className="flex items-center gap-4 mb-3">
          <div className={`flex items-center gap-2 ${dirColor}`}>
            <DirIcon className="w-8 h-8" />
            <div>
              <div className="text-2xl font-bold font-mono">{signal.direction}</div>
              <div className="text-[10px] text-muted-foreground">Confidence: {signal.confidence}%</div>
            </div>
          </div>

          <div className="flex-1 h-2 bg-zinc-800 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-1000 ${signal.direction === "BULLISH" ? "bg-green-500" : signal.direction === "BEARISH" ? "bg-red-500" : "bg-yellow-500"}`}
              style={{ width: `${signal.confidence}%` }}
            />
          </div>
          <span className={`text-sm font-mono font-bold ${dirColor}`}>{signal.confidence}%</span>
        </div>

        <p className="text-[11px] text-foreground/80 leading-relaxed mb-3">{signal.summary}</p>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
          <div className="bg-black/20 rounded p-2 text-center">
            <div className="text-[9px] text-muted-foreground">DXY</div>
            <div className="text-xs font-mono font-bold text-foreground">{signal.dxyValue?.toFixed(2) ?? "—"}</div>
          </div>
          <div className="bg-black/20 rounded p-2 text-center">
            <div className="text-[9px] text-muted-foreground">Gold</div>
            <div className="text-xs font-mono font-bold text-yellow-400">${signal.goldPrice?.toFixed(0) ?? "—"}</div>
          </div>
          <div className="bg-black/20 rounded p-2 text-center">
            <div className="text-[9px] text-muted-foreground">Oil</div>
            <div className="text-xs font-mono font-bold text-orange-400">${signal.oilPrice?.toFixed(2) ?? "—"}</div>
          </div>
          <div className="bg-black/20 rounded p-2 text-center">
            <div className="text-[9px] text-muted-foreground">VIX</div>
            <div className={`text-xs font-mono font-bold ${(signal.vixValue ?? 0) > 20 ? "text-red-400" : "text-green-400"}`}>{signal.vixValue?.toFixed(1) ?? "—"}</div>
          </div>
        </div>

        <div className="space-y-1">
          <div className="text-[9px] text-muted-foreground uppercase tracking-widest">Key Factors</div>
          {signal.factors.slice(0, 4).map((f, i) => (
            <div key={i} className="flex items-start gap-2 text-[10px] text-foreground/70">
              <Zap className="w-3 h-3 text-primary shrink-0 mt-0.5" />
              <span>{f}</span>
            </div>
          ))}
        </div>

        <div className="mt-3 flex gap-3 text-[10px]">
          <span className="text-muted-foreground">Fed: <span className={signal.fedSignal === "hawkish" ? "text-green-400" : signal.fedSignal === "dovish" ? "text-red-400" : "text-yellow-400"}>{signal.fedSignal?.toUpperCase()}</span></span>
          <span className="text-muted-foreground">Geo Risk: <span className={signal.geopoliticalRisk === "extreme" || signal.geopoliticalRisk === "high" ? "text-red-400" : "text-yellow-400"}>{signal.geopoliticalRisk?.toUpperCase()}</span></span>
        </div>
      </div>
    </div>
  );
}

function IpoBox() {
  const [, setLocation] = useLocation();
  const { data: ipos = [], isLoading } = useQuery<IpoListing[]>({
    queryKey: ["ipo-listings"],
    queryFn: async () => {
      const res = await fetch("/api/ipo");
      if (!res.ok) throw new Error("Failed to fetch IPO data");
      return res.json();
    },
    refetchInterval: 60 * 1000,
  });

  if (isLoading) {
    return (
      <div className="bg-card border border-border rounded-lg p-4 animate-pulse">
        <div className="h-24" />
      </div>
    );
  }

  const upcoming = ipos.filter(i => i.status === "upcoming" || i.status === "open");
  const listed = ipos.filter(i => i.status === "listed");
  const displayIpos = [...upcoming, ...listed].slice(0, 8);

  const getScoreColor = (score: number | null) => {
    if (!score) return "text-muted-foreground";
    if (score >= 40) return "text-green-400";
    if (score >= 30) return "text-yellow-400";
    return "text-red-400";
  };

  const getRecColor = (rec: string | null) => {
    if (!rec) return "text-muted-foreground";
    if (rec === "APPLY") return "text-green-400 bg-green-950/30 border-green-800/40";
    if (rec === "RISKY") return "text-yellow-400 bg-yellow-950/30 border-yellow-800/40";
    return "text-red-400 bg-red-950/30 border-red-800/40";
  };

  const getStatusBadge = (status: string) => {
    if (status === "open") return "bg-green-900/40 text-green-400 border-green-700/50";
    if (status === "upcoming") return "bg-blue-900/40 text-blue-400 border-blue-700/50";
    return "bg-zinc-800 text-zinc-400 border-zinc-700";
  };

  return (
    <div className="bg-card border border-border rounded-lg overflow-hidden">
      <div className="px-4 py-2 border-b border-border flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Rocket className="w-4 h-4 text-primary" />
          <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Upcoming IPOs · Indian Markets</span>
        </div>
        <button
          onClick={() => setLocation("/stocks?tab=ipo")}
          className="flex items-center gap-1 text-[10px] text-primary hover:text-primary/80 transition-colors"
        >
          View All <ChevronRight className="w-3 h-3" />
        </button>
      </div>

      {displayIpos.length === 0 ? (
        <div className="p-6 text-center text-[11px] text-muted-foreground">
          No upcoming IPOs detected. Checking RSS feeds and market sources...
        </div>
      ) : (
        <div className="divide-y divide-border/50">
          {displayIpos.map(ipo => (
            <div
              key={ipo.id}
              className="px-4 py-2.5 hover:bg-zinc-900/50 cursor-pointer transition-colors flex items-center gap-3"
              onClick={() => setLocation(`/stocks?tab=ipo&ipoId=${ipo.id}`)}
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-foreground truncate">{ipo.companyName}</span>
                  <span className={`text-[8px] px-1.5 py-0.5 rounded border font-bold ${getStatusBadge(ipo.status)}`}>
                    {ipo.status.toUpperCase()}
                  </span>
                </div>
                <div className="flex items-center gap-3 mt-0.5 text-[10px] text-muted-foreground">
                  {ipo.priceRange && <span>₹{ipo.priceRange}</span>}
                  {ipo.issueSize && <span>{ipo.issueSize}</span>}
                  {ipo.openDate && <span>{ipo.openDate}</span>}
                </div>
              </div>

              {ipo.gmp !== null && ipo.gmp !== undefined && (
                <div className={`text-right ${ipo.gmp > 0 ? "text-green-400" : ipo.gmp < 0 ? "text-red-400" : "text-muted-foreground"}`}>
                  <div className="text-[9px] text-muted-foreground">GMP</div>
                  <div className="text-xs font-mono font-bold">₹{ipo.gmp}</div>
                </div>
              )}

              {ipo.totalScore !== null && (
                <div className="text-right">
                  <div className="text-[9px] text-muted-foreground">Score</div>
                  <div className={`text-xs font-mono font-bold ${getScoreColor(ipo.totalScore)}`}>{ipo.totalScore}/50</div>
                </div>
              )}

              {ipo.recommendationListing && (
                <span className={`text-[8px] px-1.5 py-0.5 rounded border font-bold ${getRecColor(ipo.recommendationListing)}`}>
                  {ipo.recommendationListing}
                </span>
              )}

              <ChevronRight className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export function Dashboard() {
  const { data: overview, isLoading: overviewLoading } = useGetDashboardOverview();
  const { data: summary } = useGetMarketSummary();
  const { data: movers } = useGetTopMovers();
  const { data: breaking } = useGetBreakingNews();

  if (overviewLoading) {
    return (
      <div className="flex-1 p-4 space-y-3">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="h-20 bg-card rounded border border-border animate-pulse" />
        ))}
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-auto p-3 sm:p-4 space-y-3 sm:space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-base font-semibold text-foreground">Global Intelligence Overview</h1>
          <p className="text-[11px] text-muted-foreground">
            {overview?.updatedAt ? `Last updated ${new Date(overview.updatedAt).toLocaleTimeString()}` : "Live"}
          </p>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-2 h-2 rounded-full bg-green-500 live-pulse" />
          <span className="text-[10px] text-muted-foreground uppercase tracking-widest">Live</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <UsdSignalBox />
        <IpoBox />
      </div>

      <div className="bg-card border border-border rounded p-3">
        <div className="flex items-center gap-2 mb-1">
          <Shield className="w-3.5 h-3.5 text-primary" />
          <span className="text-[10px] text-muted-foreground uppercase tracking-widest">Key Conclusion</span>
        </div>
        <p className="text-sm text-foreground leading-relaxed">{overview?.keyConclusion}</p>
        <div className="mt-2 flex gap-4 text-[11px]">
          <span className="text-muted-foreground">Top Risk: <span className="text-red-400 font-medium">{overview?.topRiskRegion}</span></span>
          <span className="text-muted-foreground">Opportunity: <span className="text-green-400 font-medium">{overview?.topOpportunityRegion}</span></span>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {summary && (
          <>
            <div className="bg-card border border-border rounded p-3">
              <div className="text-[10px] text-muted-foreground uppercase tracking-widest mb-1">VIX</div>
              <div className={`text-lg font-mono font-bold ${summary.vix > 20 ? "text-red-400" : summary.vix > 15 ? "text-yellow-400" : "text-green-400"}`}>
                {summary.vix.toFixed(2)}
              </div>
              <div className="text-[10px] text-muted-foreground">Fear/Greed: {summary.fearGreedIndex}</div>
            </div>
            <div className="bg-card border border-border rounded p-3">
              <div className="text-[10px] text-muted-foreground uppercase tracking-widest mb-1">DXY</div>
              <div className="text-lg font-mono font-bold text-foreground">{summary.dollarIndex.toFixed(2)}</div>
              <div className="text-[10px] text-muted-foreground">US Dollar Index</div>
            </div>
            <div className="bg-card border border-border rounded p-3">
              <div className="text-[10px] text-muted-foreground uppercase tracking-widest mb-1">Gold</div>
              <div className="text-lg font-mono font-bold text-yellow-400">${summary.goldPrice.toFixed(0)}</div>
              <div className="text-[10px] text-muted-foreground">Safe haven</div>
            </div>
            <div className="bg-card border border-border rounded p-3">
              <div className="text-[10px] text-muted-foreground uppercase tracking-widest mb-1">Oil (WTI)</div>
              <div className="text-lg font-mono font-bold text-orange-400">${summary.oilPrice.toFixed(2)}</div>
              <div className="text-[10px] text-muted-foreground">Per barrel</div>
            </div>
          </>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-card border border-border rounded p-3">
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp className="w-3.5 h-3.5 text-green-400" />
            <span className="text-[10px] text-muted-foreground uppercase tracking-widest">Top Gainers</span>
          </div>
          <div className="space-y-2">
            {movers?.gainers.slice(0, 5).map(a => (
              <div key={a.id} data-testid={`gainer-${a.symbol}`} className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-mono font-semibold text-foreground">{a.symbol}</span>
                  <span className="text-[10px] text-muted-foreground ml-2">{a.name}</span>
                </div>
                <div className="text-right">
                  <div className="text-xs font-mono text-foreground">{a.price.toLocaleString()}</div>
                  <div className="text-[11px] flex items-center gap-0.5 text-green-400 justify-end">
                    <ArrowUpRight className="w-2.5 h-2.5" />
                    +{a.changePercent.toFixed(2)}%
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-card border border-border rounded p-3">
          <div className="flex items-center gap-2 mb-3">
            <TrendingDown className="w-3.5 h-3.5 text-red-400" />
            <span className="text-[10px] text-muted-foreground uppercase tracking-widest">Top Losers</span>
          </div>
          <div className="space-y-2">
            {movers?.losers.slice(0, 5).map(a => (
              <div key={a.id} data-testid={`loser-${a.symbol}`} className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-mono font-semibold text-foreground">{a.symbol}</span>
                  <span className="text-[10px] text-muted-foreground ml-2">{a.name}</span>
                </div>
                <div className="text-right">
                  <div className="text-xs font-mono text-foreground">{a.price.toLocaleString()}</div>
                  <div className="text-[11px] flex items-center gap-0.5 text-red-400 justify-end">
                    <ArrowDownRight className="w-2.5 h-2.5" />
                    {a.changePercent.toFixed(2)}%
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {breaking && breaking.length > 0 && (
        <div className="bg-card border border-border rounded p-3">
          <div className="flex items-center gap-2 mb-3">
            <Newspaper className="w-3.5 h-3.5 text-red-400" />
            <span className="text-[10px] text-muted-foreground uppercase tracking-widest">Breaking News</span>
          </div>
          <div className="space-y-3">
            {breaking.slice(0, 3).map(n => (
              <div key={n.id} data-testid={`breaking-news-${n.id}`} className="border-l-2 border-red-500 pl-3">
                <div className="text-xs font-medium text-foreground leading-snug">{n.headline}</div>
                <div className="text-[10px] text-muted-foreground mt-0.5">{n.source} · {new Date(n.publishedAt).toLocaleTimeString()}</div>
                <div className="text-[10px] text-primary mt-1">{n.marketConclusion}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
