# GlobalPulse Intelligence

See deploy/DEPLOY.md for setup instructions.
Fill in .env.example → rename to .env.
